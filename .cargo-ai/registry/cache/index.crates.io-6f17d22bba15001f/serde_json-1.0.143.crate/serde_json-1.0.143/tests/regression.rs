#![allow(clippy::elidable_lifetime_names, clippy::needless_lifetimes)]

mod regression {
    automod::dir!("tests/regression");
}
